const express = require('express');

const mongoose = require('mongoose');
const bodyparser = require("body-parser")

const formRoutes = require("./routes/form")
const indexRoutes = require("./routes/index")

const app = express();
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({useUnifiedTopology:true}))

mongoose.connect('mongodb://0.0.0.0:27017/ejs', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB:', error.message);
  });

app.set('view engine', 'ejs');
app.set('views', './views');


app.use('/', indexRoutes);
app.use('/form', formRoutes);

app.listen(3000, () => {
    console.log('Server started on port 3000');
  });