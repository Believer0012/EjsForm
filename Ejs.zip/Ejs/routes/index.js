const express = require('express')

const router = express.Router();
const { Form } = require('../models/form');




router.get('/', (req, res) => {
    res.render('index')
});

// router.get('/', (req, res) => {

//     Form.find({}, (err, formData) => {
//       if (err) {
//         console.error(err);
//         res.status(500).send('Error fetching data');

//       } else {



//         res.render('index', { formData });


//       }
//     });
//   });
router.get('/view', (req, res) => {
    Form.find()
        .then(formData => {
            res.render('index', { formData: formData }); 
        })
        .catch(err => {
            console.error('Error fetching items:', err);
            res.status(500).send('Error fetching items');
        });
});

module.exports = router;
