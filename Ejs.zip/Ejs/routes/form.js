const express = require('express');

const router = express.Router();
const { Form } = require('../models/form');



router.get('/form', (req, res) => {
  res.render('form')
});


router.post('/form', (req, res) => {

  response = {
    nme: req.body.name,
    mail: req.body.email,
    mesaage1: req.body.message
  }
  console.log(response);



  const newForm = new Form({
    name: req.body.name,
    email: req.body.email,
    message: req.body.message
  });
  newForm.save()
    .then(() => {
      console.log(newForm)
      res.redirect('/view');
    })
    .catch((err) => {
      console.log("error", err);
    })


})

// router.get('/edit/:name', (req, res) => {
//   const name = req.params.name;
//   Form.find({ name: name }, (err, formData) => {
//     if (err) {
//       console.error('Error fetching items:', err);
//       res.status(500).send('Error fetching items');
//     } else {

//       res.render('edit', { formData: formData });
//     }
//   });
// });
  router.get('/edit/:name', (req, res) => {
    const name = req.params.name;
    Form.find({name: name})
        .then(formData => {
          console.log(formData);

            res.render('edit', { formData: formData }); 

        })
        .catch(err => {
            console.error('Error fetching items:', err);
            res.status(500).send('Error fetching items');
        });
});


// router.post('/edit/:name', (req, res) => {
//   const name = req.params.name;
//   const { email, message } = req.body;

//   Form.findOneAndUpdate({ name: name }, { email, message }, (err) => {
//     if (err) {
//       console.error(err);
//     } else {
//       res.redirect('/view');
//     }
//   });
// });

router.post('/edit/:name',(req,res)=>{
  const name = req.params.name
  const {email,message} = req.body;

  Form.updateOne({ name: name }, { email, message })
  .then(()=>{
    console.log("updated success");
    res.redirect('/view')
  })
  .catch((err)=>{
    console.log('error');
    res.status(500).send('Error fetching items');
  })
})




// router.get('/delete/:name', async (req, res) => {
//   const name = req.params.name;

//   try {
//     await Form.deleteOne({ name: name });
//     res.redirect('/');
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Internal Server Error');
//   }
// });

router.get('/delete/:name',(req,res)=>{
  const name = req.params.name
  
  Form.deleteOne({ name: name })
  .then(()=>{
    console.log("deleted success");
    res.redirect('/view')
  })
  .catch((err)=>{
    console.log('error');
    res.status(500).send('Error deleting items');
  })
})



module.exports = router;