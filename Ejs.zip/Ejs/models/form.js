const moongose = require("mongoose")

const Form = moongose.model('Form',{
    name:String,
    email:String,
    message:String
})

module.exports={Form}